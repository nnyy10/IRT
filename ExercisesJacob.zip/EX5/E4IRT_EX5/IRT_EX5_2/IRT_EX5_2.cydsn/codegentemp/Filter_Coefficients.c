#include "Filter.h"
#include "Filter_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelABiquadCoefficients Filter_ChannelABiquadCoefficients

/* Number of Biquad sections are: 1 */

const uint8 CYCODE Filter_ChannelABiquadCoefficients[Filter_BIQUAD_A_SIZE] = 
{
 /* Coefficients of Section 0 */
 0xBEu, 0x55u, 0x23u, 0x00u, /* Section(0)_A0, 0.552108287811279 */

 0x05u, 0x1Eu, 0xE1u, 0x00u, /* Section(0)_A1, -0.482542753219604 */

 0x00u, 0x00u, 0x00u, 0x00u, /* Section(0)_A2, 0 */

 0xB5u, 0x37u, 0x02u, 0x00u, /* Section(0)_B1, -0.0346500873565674 */

 0x00u, 0x00u, 0x00u, 0x00u, /* Section(0)_B2, 0 */
};

